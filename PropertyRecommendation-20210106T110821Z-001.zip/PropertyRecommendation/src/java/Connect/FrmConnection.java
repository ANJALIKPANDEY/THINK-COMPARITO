package Connect;


import java.sql.*;

public class FrmConnection {
    public Connection con;
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/propertyrecommender", "root", "");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    public static void main(String[] args) {
        System.out.println("con--"+new FrmConnection().con);
    }
}
